# ATLAS INTELLIGENCE — dossier de déploiement

Plateforme de veille par flux RSS, classement thématique et analyse assistée par IA avec un focus sur les effets potentiels pour l'Algérie.

## Ce que contient ce projet
- Interface web responsive en français.
- API FastAPI.
- Collecte RSS planifiée toutes les 15 minutes.
- Stockage SQLite sur disque persistant.
- Détection de doublons par URL.
- Classement initial par catégories.
- Analyse IA facultative par article via l'API OpenAI.
- Affichage des liens vers les sources originales.
- Configuration de déploiement Render incluse.

## Important : ce qui n'est pas inclus
- Aucun abonnement d'hébergement ou nom de domaine n'est acheté.
- Aucune clé API n'est incluse. La clé OpenAI doit être créée et ajoutée par le propriétaire.
- Les flux RSS sont des points de départ, pas une couverture exhaustive de « toutes les nouvelles mondiales ».
- Les flux peuvent changer, être indisponibles, être soumis à des limites ou à des conditions de réutilisation.
- Le système ne lit pas nécessairement l'article complet : il traite les titres et extraits disponibles dans les flux.
- L'IA ne constitue pas une vérification journalistique ou un renseignement certifié. Elle doit expliciter les incertitudes et les informations manquantes.

## Déploiement conseillé (Render)
1. Créer un compte Render et un compte GitHub.
2. Décompresser ce dossier et importer le contenu dans un nouveau dépôt GitHub privé.
3. Dans Render, choisir **New > Blueprint** et connecter le dépôt.
4. Render détecte `render.yaml`. Vérifier le plan `starter` et créer le service.
5. Lors de la configuration, ajouter `OPENAI_API_KEY` dans les variables d'environnement du service. Créer cette clé depuis le compte OpenAI du propriétaire.
6. Attendre la fin du déploiement. Render attribue une adresse `https://...onrender.com`.
7. Ouvrir l'adresse publique et tester `/api/status`.
8. Acheter/connecter un domaine personnalisé uniquement si souhaité.

Le plan `starter` et le disque persistant sont indiqués pour un service continu. Les tarifs, conditions et disponibilités de Render peuvent évoluer : vérifier le prix affiché avant de confirmer. Une clé API et l'hébergement peuvent engendrer des coûts récurrents.

## Déploiement Docker local
Prérequis : Docker installé.
```bash
docker build -t atlas-intelligence .
docker run --rm -p 10000:10000 \
  -e OPENAI_API_KEY="VOTRE_CLE" \
  -e ADMIN_TOKEN="UN_SECRET_LONG" \
  -v "$PWD/data:/var/data" \
  -e DATABASE_PATH=/var/data/atlas.db \
  atlas-intelligence
```
Puis ouvrir `http://localhost:10000`.

## Ajouter / modifier les sources
Modifier la liste `FEEDS` dans `app/main.py`. Avant d'ajouter un flux :
- vérifier qu'il s'agit bien du flux officiel ;
- vérifier les conditions d'utilisation et les droits applicables ;
- privilégier les flux RSS/API officiels ;
- éviter de contourner les paywalls ou les mesures d'accès.

## Fréquence
La boucle de collecte démarre au lancement du serveur, puis recommence toutes les 15 minutes. Le premier cycle peut durer plusieurs minutes. Les articles en attente d'analyse sont traités par lots de 25 par cycle.

## Sécurité et exploitation
- Ne jamais publier la clé API dans le code ou dans GitHub.
- Restreindre les accès au tableau de bord de l'hébergeur et au dépôt.
- Sauvegarder régulièrement le disque contenant SQLite.
- Pour une exploitation à grande échelle, remplacer SQLite par PostgreSQL et séparer le collecteur dans un worker dédié.
- Mettre en place une supervision, des alertes de panne et un contrôle de santé des flux.
- Le site public est en lecture seule ; l'endpoint de collecte manuelle est protégé par `ADMIN_TOKEN`.

## Limites de l'analyse
Chaque analyse est fondée sur le titre et le résumé fournis par le flux. Le moteur doit afficher la source et son lien. Il ne doit pas présenter une interprétation comme un fait confirmé, ni inférer des informations classifiées ou non publiques.
