import os, re, json, time, sqlite3, asyncio, logging
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import urlparse
import httpx
import feedparser
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("atlas")

DB_PATH = os.getenv("DATABASE_PATH", "atlas.db")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")
INTERVAL_MINUTES = max(5, int(os.getenv("COLLECTION_INTERVAL_MINUTES", "15")))
MAX_PER_FEED = int(os.getenv("MAX_ITEMS_PER_FEED", "12"))

# Sources publiques RSS. Ajouter/retirer des flux après vérification de leurs conditions d'utilisation.
FEEDS = [
    {"name":"BBC World","url":"https://feeds.bbci.co.uk/news/world/rss.xml","category":"International"},
    {"name":"BBC Business","url":"https://feeds.bbci.co.uk/news/business/rss.xml","category":"Économie"},
    {"name":"France 24","url":"https://www.france24.com/en/rss","category":"International"},
    {"name":"Al Jazeera","url":"https://www.aljazeera.com/xml/rss/all.xml","category":"International"},
    {"name":"UN News","url":"https://news.un.org/feed/subscribe/en/news/all/rss.xml","category":"Diplomatie"},
    {"name":"World Bank","url":"https://www.worldbank.org/en/news/all?format=rss","category":"Économie"},
    {"name":"IMF News","url":"https://www.imf.org/en/News/RSS","category":"Économie"},
    {"name":"Africanews","url":"https://www.africanews.com/feed/rss","category":"Afrique"},
    {"name":"APS Algérie","url":"https://www.aps.dz/rss","category":"Algérie"},
    {"name":"Euronews","url":"https://www.euronews.com/rss?level=theme&name=news","category":"International"},
]
CATEGORIES = ["Politique","Économie","Sécurité","Industrie","Affaires étrangères","Énergie","Technologie","Culture","International","Afrique","Algérie","Autre"]

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS articles(
            id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT UNIQUE, title TEXT, summary TEXT,
            source TEXT, category TEXT, region TEXT, published TEXT, collected TEXT,
            analysis TEXT, impact TEXT, opportunities TEXT, risks TEXT, confidence TEXT,
            status TEXT DEFAULT 'À analyser'
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS system_state(
            key TEXT PRIMARY KEY, value TEXT
        )""")

def clean(s):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", str(s or ""))).strip()[:6000]

def published_date(entry):
    for key in ("published", "updated", "created"):
        val = entry.get(key)
        if val:
            try:
                return parsedate_to_datetime(val).astimezone(timezone.utc).isoformat()
            except Exception:
                try:
                    return datetime(*entry.get("published_parsed")[:6], tzinfo=timezone.utc).isoformat()
                except Exception:
                    pass
    return datetime.now(timezone.utc).isoformat()

def classify(title, summary, fallback):
    t = (title + " " + summary).lower()
    rules = [
        ("Sécurité", ["security","military","army","war","attack","terror","border","defence","defense","conflict","sécurité","armée"]),
        ("Énergie", ["oil","gas","energy","electricity","renewable","pétrole","gaz","énergie"]),
        ("Industrie", ["industry","manufacturing","factory","industrial","industrie","usine","production"]),
        ("Technologie", ["technology","artificial intelligence","semiconductor","digital","cyber","technologie","intelligence artificielle"]),
        ("Économie", ["economy","economic","trade","market","inflation","finance","growth","économie","commerce","marché"]),
        ("Affaires étrangères", ["diplomacy","foreign minister","summit","treaty","ambassador","diplomatie"]),
        ("Politique", ["election","president","government","parliament","minister","political","élection","président","gouvernement"]),
        ("Culture", ["culture","film","music","heritage","festival","culturel","patrimoine"]),
    ]
    for cat, words in rules:
        if any(w in t for w in words):
            return cat
    return fallback if fallback in CATEGORIES else "International"

async def ai_analyze(title, summary, source, url, category):
    if not OPENAI_API_KEY:
        return {
            "analysis":"Analyse IA non activée : ajoutez OPENAI_API_KEY dans les variables d'environnement. Le résumé affiché provient du flux source et n'a pas été vérifié indépendamment.",
            "impact":"Non évalué", "opportunities":"À examiner après vérification des faits.",
            "risks":"Risque de contexte incomplet ou de reprise d'une information non confirmée.",
            "confidence":"Non évaluée"
        }
    prompt = f"""Tu es un analyste de veille stratégique indépendant. Analyse l'information suivante exclusivement à partir des éléments fournis. Ne prétends jamais avoir vérifié des faits externes. Distingue clairement faits rapportés, interprétations et hypothèses. Concentre-toi sur les conséquences possibles pour l'Algérie, sans inventer.
Titre: {title}
Résumé du flux: {summary}
Source: {source}
URL: {url}
Catégorie indicative: {category}
Réponds en français sous forme JSON strict avec les clés: analysis (2-4 phrases), impact (impact potentiel sur l'Algérie), opportunities (opportunités possibles), risks (risques et incertitudes), confidence (Faible/Moyenne, avec raison)."""
    try:
        async with httpx.AsyncClient(timeout=45) as client:
            r = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
                json={"model": OPENAI_MODEL, "temperature":0.2,
                      "messages":[{"role":"system","content":"Tu produis des analyses prudentes, sourcées et non spéculatives."},
                                  {"role":"user","content":prompt}],
                      "response_format":{"type":"json_object"}}
            )
            r.raise_for_status()
            data = r.json()["choices"][0]["message"]["content"]
            obj = json.loads(data)
            return {k: clean(obj.get(k, "")) for k in ["analysis","impact","opportunities","risks","confidence"]}
    except Exception as e:
        log.exception("AI analysis failed")
        return {"analysis":"Analyse IA indisponible pour le moment. Consultez la source originale et réessayez.",
                "impact":"Non évalué","opportunities":"Non évaluées","risks":"Erreur de traitement ou données insuffisantes.",
                "confidence":"Non évaluée"}

async def fetch_feed(client, feed):
    try:
        r = await client.get(feed["url"], follow_redirects=True, timeout=20,
                             headers={"User-Agent":"AtlasIntelligence/1.0 (news monitoring; contact: admin)"} )
        r.raise_for_status()
        parsed = feedparser.parse(r.text)
        out = []
        for e in parsed.entries[:MAX_PER_FEED]:
            title = clean(e.get("title"))
            link = clean(e.get("link"))
            if not title or not link or not urlparse(link).scheme.startswith("http"):
                continue
            summary = clean(e.get("summary") or e.get("description"))
            out.append({"title":title,"url":link,"summary":summary,"source":feed["name"],
                        "category":classify(title, summary, feed["category"]),
                        "published":published_date(e)})
        return out
    except Exception as e:
        log.warning("Feed error %s: %s", feed["name"], e)
        return []

async def collect():
    started = datetime.now(timezone.utc).isoformat()
    async with httpx.AsyncClient() as client:
        batches = await asyncio.gather(*(fetch_feed(client, f) for f in FEEDS))
    entries = [item for batch in batches for item in batch]
    added = 0
    for item in entries:
        try:
            with db() as con:
                cur = con.execute("""INSERT OR IGNORE INTO articles
                    (url,title,summary,source,category,published,collected,status)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (item["url"],item["title"],item["summary"],item["source"],item["category"],
                     item["published"],datetime.now(timezone.utc).isoformat(),"À analyser"))
                if cur.rowcount:
                    added += 1
        except Exception:
            log.exception("DB insert failed")
    # Analyse des nouveaux articles uniquement; limite de charge par cycle.
    with db() as con:
        pending = con.execute("SELECT id,title,summary,source,url,category FROM articles WHERE status='À analyser' ORDER BY id DESC LIMIT 25").fetchall()
    for row in pending:
        result = await ai_analyze(row["title"], row["summary"], row["source"], row["url"], row["category"])
        with db() as con:
            con.execute("""UPDATE articles SET analysis=?,impact=?,opportunities=?,risks=?,confidence=?,status='Traité'
                           WHERE id=?""",
                        (result["analysis"],result["impact"],result["opportunities"],result["risks"],result["confidence"],row["id"]))
    with db() as con:
        con.execute("INSERT OR REPLACE INTO system_state(key,value) VALUES('last_collection',?)",
                    (datetime.now(timezone.utc).isoformat(),))
        con.execute("INSERT OR REPLACE INTO system_state(key,value) VALUES('last_started',?)",(started,))
    log.info("Collection finished: %s new items", added)
    return {"new":added,"fetched":len(entries)}

async def scheduler():
    while True:
        try:
            await collect()
        except Exception:
            log.exception("Collection cycle failed")
        await asyncio.sleep(INTERVAL_MINUTES * 60)

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    task = asyncio.create_task(scheduler())
    yield
    task.cancel()
    try: await task
    except asyncio.CancelledError: pass

app = FastAPI(title="ATLAS INTELLIGENCE API", version="1.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="app/static"), name="static")

@app.get("/")
async def home():
    return FileResponse("app/static/index.html")

@app.get("/api/status")
async def status():
    with db() as con:
        row = con.execute("SELECT value FROM system_state WHERE key='last_collection'").fetchone()
        count = con.execute("SELECT COUNT(*) n FROM articles").fetchone()["n"]
    return {"service":"online","last_collection":row["value"] if row else None,
            "interval_minutes":INTERVAL_MINUTES,"articles":count,
            "ai_enabled":bool(OPENAI_API_KEY),"source_count":len(FEEDS)}

@app.get("/api/articles")
async def articles(category: str = "Toutes", q: str = "", limit: int = 100, offset: int = 0):
    limit = min(max(limit,1),200)
    sql = "SELECT * FROM articles"
    params = []
    clauses = []
    if category and category != "Toutes":
        clauses.append("category=?"); params.append(category)
    if q:
        clauses.append("(title LIKE ? OR summary LIKE ? OR analysis LIKE ? OR source LIKE ?)")
        params += [f"%{q}%"]*4
    if clauses: sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY published DESC LIMIT ? OFFSET ?"
    params += [limit,offset]
    with db() as con:
        rows = con.execute(sql,params).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/refresh")
async def refresh(x_atlas_admin_token: str = Header(default="")):
    if not ADMIN_TOKEN or x_atlas_admin_token != ADMIN_TOKEN:
        raise HTTPException(status_code=403, detail="Action réservée à l'administrateur.")
    return await collect()
